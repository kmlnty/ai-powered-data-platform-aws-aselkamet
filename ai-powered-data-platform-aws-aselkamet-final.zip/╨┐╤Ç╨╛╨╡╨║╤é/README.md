# AI-Powered Data Platform on AWS (Local Simulation)
Author: Asel Kamet

## 📦 How to Run This Project (Mac)

### 1. Install Python packages (run this in Terminal)
```
pip install pandas textblob pillow prophet streamlit
```

### 2. Run Jupyter Notebook
```
jupyter notebook
```
- Open the file: `unified_run.ipynb`
- Run cells step-by-step to see ETL + NLP + CV + Forecast

### 3. Run the Dashboard (Streamlit)
```
streamlit run dashboards/streamlit_app.py
```
- Will open in your browser: http://localhost:8501/

### Notes:
- No real AWS account is required. All services are simulated.
- Make sure your data is in the `data/` folder.
- Python 3.9+ is recommended.

