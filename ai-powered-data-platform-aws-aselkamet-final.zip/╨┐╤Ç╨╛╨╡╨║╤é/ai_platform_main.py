# AI-Powered Data Platform – Unified Script
# Author: Asel Kamet

import pandas as pd
from textblob import TextBlob
from prophet import Prophet
from PIL import Image
import os

# === ETL Step ===
def run_etl():
    df = pd.read_csv("data/sales.csv")
    df.columns = df.columns.str.strip().str.lower()
    df['date'] = pd.to_datetime(df['date'])
    df = df.dropna()
    df.to_csv("data/clean_sales.csv", index=False)
    print("✅ ETL complete")
    return df

# === NLP Step ===
def run_nlp():
    texts = ["Great product!", "Terrible experience", "Would buy again."]
    sentiments = [{"text": t, "polarity": TextBlob(t).sentiment.polarity} for t in texts]
    print("✅ NLP Sentiment Results:")
    for s in sentiments:
        print(s)

# === Computer Vision (Placeholder) ===
def run_cv():
    try:
        img = Image.open("data/sample_image.jpg")
        print(f"✅ Loaded image: {img.format}, {img.size}")
    except:
        print("⚠️ Image not found (place a sample_image.jpg in /data)")

# === Time Series Forecasting ===
def run_forecast(df):
    df_prophet = df.rename(columns={'date': 'ds', 'sales': 'y'})
    model = Prophet()
    model.fit(df_prophet)
    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    forecast[['ds', 'yhat']].to_csv("data/forecast.csv", index=False)
    print("✅ Forecast complete and saved")

# === Main Orchestration ===
def run_pipeline():
    df = run_etl()
    run_nlp()
    run_cv()
    run_forecast(df)

if __name__ == "__main__":
    run_pipeline()
